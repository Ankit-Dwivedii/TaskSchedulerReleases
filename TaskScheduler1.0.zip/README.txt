Welcome to Task Scheduler Bat!

ALL OF THIS INFO IS ALSO IN INTRO.MP4 AND ON YOUTUBE AT https://youtu.be/jONeIJB0rSQ

----How to use----

----------------------------------------------------------
1: Run the NewTask.exe (It may say that it is unsafe to run, but I ensure you it is not. For absolute conformation of this, I have also included an Intro video [intro.mp4])

2: Provide a name for your task

3: Provide the directory that contains the file/program

4: Provide the name of the file/program (including the extension. ex: .exe, .bat, .txt, ETC.)

5: Provide the time you would like the program/file to run in 24 Hour format (A.K.A. Military time)
----------------------------------------------------------

----Notes----

----------------------------------------------------------
When you finish task.exe will automatically run so you do not have to find and run it.

As soon as the time that you have provided (Seen on the title of task.exe) is reached, your program/file will be triggered.

If you restart your computer and need to re-run task.exe, find it for your task in Tasks/(task name)/task.exe.

If for some reason you need to change file-name, file-location, or time edit Tasks/(task name)/task.sav.
----------------------------------------------------------